// �S���F�ѓ�
#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "CameraModifierDataAsset.generated.h"

/**
 * 
 */
UCLASS()
class OTOGIACTION_API UCameraModifierDataAsset : public UDataAsset
{
	GENERATED_BODY()

public:
	//SpringArm�̒����ւ̉��Z
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera|SpringArm")
	float TargetArmLengthOffset = 0.0f;


	//SpringArm�̃\�P�b�g�I�t�Z�b�g
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera|SpringArm")
	FVector SocketOffset = FVector::ZeroVector;

	
	//SpringArm�̉�]offset
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera|SpringArm")
	FRotator RotationOffset = FRotator::ZeroRotator;

	//FOV�̉��Z
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera|Lens")
	float FOVOffset = 0.0f;

	//�K�����x
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera")
	float InterpSpeed = 5.0f;
};
