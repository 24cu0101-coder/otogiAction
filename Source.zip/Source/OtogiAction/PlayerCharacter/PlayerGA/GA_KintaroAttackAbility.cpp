// Fill out your copyright notice in the Description page of Project Settings.


#include "GA_KintaroAttackAbility.h"
#include "Abilities/Tasks/AbilityTask_PlayMontageAndWait.h"

//�R���X�g���N�^
UGA_KintaroAttackAbility::UGA_KintaroAttackAbility()
{

}

//ability�̔����֐�
void UGA_KintaroAttackAbility::ActivateAbility(const FGameplayAbilitySpecHandle Handle, const FGameplayAbilityActorInfo* ActorInfo, const FGameplayAbilityActivationInfo ActivationInfo, const FGameplayEventData* TriggerEventData)
{
	if (KintaroAttackMontage)
	{
		//�����^�[�W���^�X�N�쐬
		UAbilityTask_PlayMontageAndWait* PlayMontageTask = UAbilityTask_PlayMontageAndWait::CreatePlayMontageAndWaitProxy(this,TEXT("KintaroAttackAction"),KintaroAttackMontage,1.0f);

		if (PlayMontageTask)
		{
			PlayMontageTask->OnCompleted.AddDynamic(this, &UGA_KintaroAttackAbility::OnMontageFinished);
			PlayMontageTask->OnInterrupted.AddDynamic(this, &UGA_KintaroAttackAbility::OnMontageFinished);
			PlayMontageTask->OnCancelled.AddDynamic(this, &UGA_KintaroAttackAbility::OnMontageFinished);

			PlayMontageTask->ReadyForActivation();
		}
		else
		{
			EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		}
	}
	else
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
	}
}

//Ability�̏I��
void UGA_KintaroAttackAbility::OnMontageFinished()
{
	EndAbility(CurrentSpecHandle, CurrentActorInfo, CurrentActivationInfo, true, false);
}
