//�S���F�C�C�W�}


#include "AN_PlaySound.h"

#include "Components/SkeletalMeshComponent.h"
#include "../../Component/Audio/BGMManager.h"
#include "Sound/SoundBase.h"

void UAN_PlaySound::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	Super::Notify(MeshComp, Animation);

	// Mesh�����݂��Ȃ�
	if (!MeshComp) return;

	// Mesh��Owner���擾
	AActor* Owner = MeshComp->GetOwner();

	if (!Owner) return;

	// Owner����SoundManagerComponent���擾
	USoundManagerComponent* SoundManager = Owner->FindComponentByClass<USoundManagerComponent>();

	if (!Sound)return;

	// �T�E���h�Đ�
	SoundManager->PlayAnimNotifySound(Sound);

}
