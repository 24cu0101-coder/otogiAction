//�S���F�C�C�W�}

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AN_PlaySound.generated.h"

//�O���錾
class USoundBase;

UCLASS()
class OTOGIACTION_API UAN_PlaySound : public UAnimNotify
{
	GENERATED_BODY()

public:

	// �ʒm�̏���
	virtual void Notify(USkeletalMeshComponent* MeshComp,
		UAnimSequenceBase* Animation,
		const FAnimNotifyEventReference& EventReference)
		override;


	// Notify�ɐݒ肷��T�E���h
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sound")
	TObjectPtr<USoundBase> Sound;
};
