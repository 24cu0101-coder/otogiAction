// Fill out your copyright notice in the Description page of Project Settings.


#include "HitReactionComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

// Sets default values for this component's properties
UHitReactionComponent::UHitReactionComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	// ...
}

// Called when the game starts
void UHitReactionComponent::BeginPlay()
{
	Super::BeginPlay();
}


// Called every frame
void UHitReactionComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

//�G�̍U���q�b�g���ɌĂ΂��֐�
void UHitReactionComponent::PlayHitReaction(float DamageAmount)
{
	ACharacter* Character = Cast<ACharacter>(GetOwner());
	if (!Character || bIsStunned) return;

	UCharacterMovementComponent* MoveComp = Character->GetCharacterMovement();

	FVector KnockbackDir = -Character->GetActorForwardVector();
	KnockbackDir.Z = 0.0f;
	KnockbackDir.Normalize();

	// �ʏ�q�b�g
	if (LightHitReactMontage)
	{
		Character->PlayAnimMontage(LightHitReactMontage);
	}
	if (MoveComp)
	{
		Character->LaunchCharacter(KnockbackDir * LightKnockbackForce, false, false);
	}
}

//�X�^���l���}�b�N�X�ɂȂ�����_�E������
void UHitReactionComponent::OnStunMax()
{
	Super::OnStunMax();


	ACharacter* Character = Cast<ACharacter>(GetOwner());
	if (!Character) return;

	//������΂������^�[�W��
	if (HeavyHitReactMontage)
	{
		Character->PlayAnimMontage(HeavyHitReactMontage);
	}

	//AddInpulse
	UCharacterMovementComponent* MoveComp = Character->GetCharacterMovement();
	if (MoveComp)
	{
		MoveComp->SetMovementMode(EMovementMode::MOVE_Falling);

		//������΂��x�N�g���F���
		FVector KnockbackDir = -Character->GetActorForwardVector();
		KnockbackDir.Z = 0.0f;
		KnockbackDir.Normalize();

		//������΂��x�N�g���F���+��
		FVector ImpulseVector = (KnockbackDir * HeavyKnockbackForce) + FVector(0.f, 0.f, 600.f);

		//������΂�
		MoveComp->AddImpulse(ImpulseVector, true);
	}


}

//�N���オ��
void UHitReactionComponent::RequestGetUp()
{
	if (!bIsStunned) return;

	ACharacter* Character = Cast<ACharacter>(GetOwner());
	if (!Character) return;

	if (GetupMontage)
	{
		Character->PlayAnimMontage(GetupMontage);

		UAnimInstance* AnimInstance = Character->GetMesh()->GetAnimInstance();
		if (AnimInstance)
		{
			AnimInstance->OnMontageEnded.AddDynamic(this, &UHitReactionComponent::OnGetUpFinished);
		}
	}
	else
	{
		// ���[�V�����Ȃ��̏ꍇ�̈��S���A
		ResetStun();
		if (Character->GetCharacterMovement())
		{
			Character->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		}
	}
}

//�N���オ���Ɉړ��\�ւƑJ��
void UHitReactionComponent::OnGetUpFinished(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage == GetupMontage)
	{
		ResetStun(); //

		ACharacter* Character = Cast<ACharacter>(GetOwner());
		if (Character && Character->GetCharacterMovement())
		{
			Character->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		}

		UAnimInstance* AnimInstance = Character->GetMesh()->GetAnimInstance();
		if (AnimInstance)
		{
			AnimInstance->OnMontageEnded.RemoveDynamic(this, &UHitReactionComponent::OnGetUpFinished);
		}
	}
}
