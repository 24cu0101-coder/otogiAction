//�S���F�ѓ�

#include "CameraTargetComponent.h"
#include "../PlayerTargetComponent.h"
#include "../../PlayerCharacter.h"
#include "GameFramework/Actor.h"

//�R���X�g���N�^
UCameraTargetComponent::UCameraTargetComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	PlayerTargetComponent = nullptr;
}


//�������ꂽ�珈�������
void UCameraTargetComponent::BeginPlay()
{
	Super::BeginPlay();

    AActor* OwnerActor = GetOwner();

    if (!OwnerActor) return;

    PlayerTargetComponent = OwnerActor->FindComponentByClass<UPlayerTargetComponent>();
}

//�A�N�^�[���擾
AActor* UCameraTargetComponent::GetTargetActor() const
{
	if (!PlayerTargetComponent) { return nullptr; }

    return PlayerTargetComponent->GetCurrentTargetActor();
}

//�ʏ펞�̃^�[�Q�b�g�����_���擾
FVector UCameraTargetComponent::GetDefaultTargetPoint() const
{
    const AActor* OwnerActor = GetOwner();

    if (!OwnerActor)
    {
        return FVector::ZeroVector;
    }

    FVector Result = OwnerActor->GetActorLocation();

    Result.Z += PlayerFocusHeight;

    return Result;
}

//�^�[�Q�b�g���̒����_���擾
FVector UCameraTargetComponent::GetLockOnTargetPoint() const
{
    const AActor* OwnerActor = GetOwner();

    if (!OwnerActor)
    {
        return FVector::ZeroVector;
    }

    AActor* TargetActor = GetTargetActor();

    if (!TargetActor)
    {
        return GetDefaultTargetPoint();
    }

    FVector PlayerPoint = OwnerActor->GetActorLocation();
    PlayerPoint.Z += PlayerFocusHeight;

    FVector EnemyPoint = TargetActor->GetActorLocation();
    EnemyPoint.Z += EnemyFocusHeight;

    const float ClampedWeight =
        FMath::Clamp(EnemyWeight, 0.0f, 1.0f);

    const float PlayerWeight =
        1.0f - ClampedWeight;

    return
        PlayerPoint * PlayerWeight +
        EnemyPoint * ClampedWeight;
}



