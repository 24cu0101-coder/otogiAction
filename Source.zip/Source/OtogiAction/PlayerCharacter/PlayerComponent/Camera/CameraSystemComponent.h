//�S���F�ѓ�
//�J��������

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CameraSystemComponent.generated.h"

//�O���錾
class UMoveCameraComponent;
class UPlayerTargetComponent;
class AActor;
class USpringArmComponent;
class UCameraComponent;
class USceneComponent;

UENUM(BlueprintType)
enum class ECameraMode : uint8
{
	Normal		UMETA(DisplayName = "Normal"),
	TargetLock	UMETA(DisplayName = "Target Lock"),
	BossBattle	UMETA(DisplayName = "Boss Battle")
};

//�J�����ݒ�\����
USTRUCT(BlueprintType)
struct FCameraSetting
{
	GENERATED_BODY()


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	float ArmLength = 400.0f;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	float FOV = 90.0f;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	FVector SocketOffset = FVector::ZeroVector;


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	float InterpSpeed = 8.0f;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class OTOGIACTION_API UCameraSystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	//�R���X�g���N�^
	UCameraSystemComponent();

protected:
	//�������ꂽ�Ƃ��ɏ��������
	virtual void BeginPlay() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

public:

	//==================================================
	// Camera
	//==================================================

	//�J��������Component��ݒ�
	void SetMoveCameraComponent(UMoveCameraComponent* CameraComponent);

	//�J�����ݒ��K��
	void ApplyCameraSetting(float DeltaTime);

	//�J��������������Ȃ��֐�
	void CameraMove(const FVector2D& InputValue);

	//�^�[�Q�b�g���̃J�����X�V
	void UpdateTargetLockCamera(float DeltaTime);

	//�^�[�Q�b�g
	void ToggleTargetLock();

	//���݂̃J�������[�h��ύX
	UFUNCTION(BlueprintCallable, Category = "Camera")
	void SetCameraMode(ECameraMode NewMode);

	void SetCameraPivotComponent(USceneComponent* CameraPivot);

	//���݂̃J�������[�h���擾
	UFUNCTION(BlueprintPure, Category = "Camera")
	ECameraMode GetCameraMode() const { return CurrentCameraMode; }


	//==================================================
	// Target
	//==================================================

	//�^�[�Q�b�gComponent��ݒ�
	void SetTargetComponent(UPlayerTargetComponent* TargetComponent);

	//���݂̃^�[�Q�b�g���擾
	UFUNCTION(BlueprintPure, Category = "Camera|Target")
	AActor* GetCurrentTarget() const;

	//�^�[�Q�b�g����
	UFUNCTION(BlueprintPure, Category = "Camera|Target")
	bool IsTargeting() const;


private:

	//==================================================
	// Camera
	//==================================================

	//���ۂɃJ�����𑀍삷��Component
	UPROPERTY()
	TObjectPtr<UMoveCameraComponent> MoveCameraComp;

	// ���݂̃J�������[�h
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
	ECameraMode CurrentCameraMode;


	//==================================================
	// Target
	//==================================================

	//�^�[�Q�b�g���Ǘ�����Component
	UPROPERTY()
	TObjectPtr<UPlayerTargetComponent> TargetComp;

	UPROPERTY()
	USceneComponent* CameraPivotComp;

	UPROPERTY()
	TObjectPtr<USpringArmComponent> SpringArmComp;

	UPROPERTY()
	TObjectPtr<UCameraComponent> CameraComp;


	UPROPERTY(EditAnywhere, Category = "Camera|TargetLock")
	float PlayerTargetPointHeight = 80.0f;

	UPROPERTY(EditAnywhere, Category = "Camera|TargetLock")
	float EnemyTargetPointHeight = 80.0f;

	UPROPERTY(EditAnywhere, Category = "Camera|TargetLock")
	float TargetCameraInterpSpeed = 8.0f;

	UPROPERTY(EditAnywhere, Category = "Camera|TargetLock")
	float MaxTargetCameraPitch = 60.0f;

	UPROPERTY(EditAnywhere, Category = "Camera|TargetLock")
	float MinTargetCameraPitch = -60.0f;
		

	//==================================================
	// Camera Settings
	//==================================================

	FCameraSetting GetCurrentCameraSetting() const;

	UPROPERTY(EditAnywhere, BlueprintReadOnly,Category = "Camera|Settings",meta = (AllowPrivateAccess = "true"))
	FCameraSetting NormalCameraSetting;


	UPROPERTY(EditAnywhere, BlueprintReadOnly,Category = "Camera|Settings",meta = (AllowPrivateAccess = "true"))
	FCameraSetting TargetLockCameraSetting;


	UPROPERTY(EditAnywhere, BlueprintReadOnly,Category = "Camera|Settings",meta = (AllowPrivateAccess = "true"))
	FCameraSetting BossBattleCameraSetting;
};
