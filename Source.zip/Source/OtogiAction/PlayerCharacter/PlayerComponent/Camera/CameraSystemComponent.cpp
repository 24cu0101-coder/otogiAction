// Fill out your copyright notice in the Description page of Project Settings.


#include "CameraSystemComponent.h"
#include "MoveCameraComponent.h"
#include "../PlayerTargetComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

//�R���X�g���N�^
UCameraSystemComponent::UCameraSystemComponent()
{
	//Tick�͖�����
	PrimaryComponentTick.bCanEverTick = true;

	MoveCameraComp = nullptr;
	TargetComp = nullptr;

	SpringArmComp = nullptr;
	CameraComp = nullptr;

	// ������Ԃ͒ʏ�J����
	CurrentCameraMode = ECameraMode::Normal;

	//==================================================
	// �m�[�}���J�����ݒ�
	//==================================================

	NormalCameraSetting.ArmLength = 400.0f;
	NormalCameraSetting.FOV = 90.0f;
	NormalCameraSetting.SocketOffset = FVector::ZeroVector;
	NormalCameraSetting.InterpSpeed = 8.0f;


	//==================================================
	// �^�[�Q�b�g�J�����ݒ�
	//==================================================

	TargetLockCameraSetting.ArmLength = 400.0f;
	TargetLockCameraSetting.FOV = 90.0f;
	TargetLockCameraSetting.SocketOffset = FVector::ZeroVector;
	TargetLockCameraSetting.InterpSpeed = 8.0f;


	//==================================================
	// �{�X�퓬�J�����ݒ�
	//==================================================

	BossBattleCameraSetting.ArmLength = 500.0f;
	BossBattleCameraSetting.FOV = 85.0f;
	BossBattleCameraSetting.SocketOffset = FVector::ZeroVector;
	BossBattleCameraSetting.InterpSpeed = 5.0f;
}


// �������ꂽ�Ƃ����������
void UCameraSystemComponent::BeginPlay()
{
	Super::BeginPlay();

	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());

	if (!OwnerCharacter)return;

	SpringArmComp = OwnerCharacter->FindComponentByClass<USpringArmComponent>();

	CameraComp = OwnerCharacter->FindComponentByClass<UCameraComponent>();
	
}

void UCameraSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime,TickType,ThisTickFunction);

	//�J�����ݒ�K��
	ApplyCameraSetting(DeltaTime);

	//�J�������[�h
	switch (CurrentCameraMode)
	{
	case ECameraMode::Normal:

		if (bReturningToNormalCamera)
		{
			UpdateReturnToNormalCamera(DeltaTime);
		}
		
		break;


	case ECameraMode::TargetLock:

		UpdateTargetLockCamera(DeltaTime);

		break;


	case ECameraMode::BossBattle:

		break;
	}
}


void UCameraSystemComponent::SetMoveCameraComponent(UMoveCameraComponent* CameraComponent)
{
	MoveCameraComp = CameraComponent;
}

void UCameraSystemComponent::ApplyCameraSetting(float DeltaTime)
{
	if (!SpringArmComp || !CameraComp) return;

	// TargetLock����SpringArm���g�p���Ȃ�
	if (CurrentCameraMode == ECameraMode::TargetLock)
	{
		CameraComp->FieldOfView =FMath::FInterpTo(CameraComp->FieldOfView,TargetLockCameraSetting.FOV,DeltaTime,TargetLockCameraSetting.InterpSpeed);
		return;
	}

	FCameraSetting Setting = GetCurrentCameraSetting();

	SpringArmComp->TargetArmLength =FMath::FInterpTo(SpringArmComp->TargetArmLength,Setting.ArmLength,DeltaTime,Setting.InterpSpeed);

	CameraComp->FieldOfView =FMath::FInterpTo(CameraComp->FieldOfView,Setting.FOV,DeltaTime,Setting.InterpSpeed);

	SpringArmComp->SocketOffset =FMath::VInterpTo(SpringArmComp->SocketOffset,Setting.SocketOffset,DeltaTime,Setting.InterpSpeed);
}

void UCameraSystemComponent::CameraMove(const FVector2D& InputValue)
{
	if (!MoveCameraComp) return;

	if (CurrentCameraMode == ECameraMode::TargetLock) return;

	// �ʏ�J�����֕��A���͑��삵�Ȃ�
	if (bReturningToNormalCamera) return;

	MoveCameraComp->CameraMove(InputValue);
}

void UCameraSystemComponent::ToggleTargetLock()
{
	if (!TargetComp)return;

	TargetComp->ToggleTargetLock();

	if (TargetComp->IsTargeting())
	{
		// TargetLock�J�n
		if (CameraComp)
		{
			CameraComp->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
		}

		SetCameraMode(ECameraMode::TargetLock);

		UE_LOG(LogTemp, Warning, TEXT("Camera Target Start"));
	}
	else
	{
		// TargetLock�I��
		SetCameraMode(ECameraMode::Normal);

		//�ʏ�J�����̕��A����擾
		if (CameraComp)
		{
			const FRotator CurrentCameraRotation =CameraComp->GetComponentRotation();

			NormalCameraReturnTargetRotation =FRotator(-20.0f,CurrentCameraRotation.Yaw,0.0f);
		}
		
		// �J������ʏ�ʒu�܂Ŗ߂�
		bReturningToNormalCamera = true;

		UE_LOG(LogTemp,Warning,TEXT("Camera Return Start"));
	}
}

//�m�[�}���J�����Ƀ��Z�b�g
void UCameraSystemComponent::ResetNormalCamera()
{
	if (!SpringArmComp || !CameraComp)return;

	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());

	if (!OwnerCharacter)return;

	// Camera��SpringArm�֖߂�
	CameraComp->AttachToComponent(SpringArmComp,FAttachmentTransformRules::SnapToTargetNotIncludingScale);

	// Camera���g��Transform�����S���Z�b�g
	CameraComp->SetRelativeLocation(FVector::ZeroVector);
	CameraComp->SetRelativeRotation(FRotator::ZeroRotator);

	// �ʏ�J�����̉�]
	const float PlayerYaw = OwnerCharacter->GetActorRotation().Yaw;

	// Player�̌�������ɂ���
	// Pitch�͏����ォ�猩��
	FRotator NormalCameraRotation(-20.0f,PlayerYaw,0.0f);

	SpringArmComp->SetWorldRotation(NormalCameraRotation);

	// �ʏ�J�����ݒ�
	SpringArmComp->TargetArmLength = NormalCameraSetting.ArmLength;

	SpringArmComp->SocketOffset = NormalCameraSetting.SocketOffset;

	CameraComp->FieldOfView = NormalCameraSetting.FOV;

	UE_LOG(
		LogTemp,
		Warning,
		TEXT("Normal Camera Reset : PlayerYaw=%f / SpringArm=%s / Camera=%s"),
		PlayerYaw,
		*SpringArmComp->GetComponentRotation().ToString(),
		*CameraComp->GetComponentLocation().ToString()
	);
}

void UCameraSystemComponent::UpdateTargetLockCamera(float DeltaTime)
{
	if (!TargetComp || !CameraComp)return;

	AActor* TargetActor = TargetComp->GetCurrentTargetActor();

	if (!TargetActor) return;

	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());

	if (!OwnerCharacter) return;

	// Player�ʒu
	FVector PlayerLocation = OwnerCharacter->GetActorLocation();

	PlayerLocation.Z += PlayerTargetPointHeight;


	// Enemy�ʒu
	FVector TargetLocation = GetEnemyTargetPoint();

	// 2�l�̒��S
	FVector CenterLocation = (PlayerLocation + TargetLocation) * 0.5f;


	// Player��Enemy�̋���

	float Distance =FVector::Distance(PlayerLocation,TargetLocation);

	// �ő勗���𒴂�����TargetLock�I��
	if (Distance >= MaxTargetCameraDistance)
	{
		TargetComp->ToggleTargetLock();

		SetCameraMode(ECameraMode::Normal);

		//���A���
		if (CameraComp)
		{
			const FRotator CurrentCameraRotation =CameraComp->GetComponentRotation();

			NormalCameraReturnTargetRotation =FRotator(-20.0f,CurrentCameraRotation.Yaw,0.0f);
		}

		bReturningToNormalCamera = true;

		UE_LOG(LogTemp,Warning,TEXT("Target Lock End : Distance = %f / MaxDistance = %f"),Distance,MaxTargetCameraDistance);

		return;
	}


	// �J��������
	float CameraDistance =FMath::Clamp(Distance * 1.2f,MinTargetCameraDistance,MaxTargetCameraDistance);


	// Player �� Enemy

	FVector Direction = (TargetLocation - PlayerLocation).GetSafeNormal();

	if (Direction.IsNearlyZero())return;


	// �J������2�l�̌��ɔz�u
	FVector CameraDirection = -Direction;

	CameraDirection.Z = 0.0f;
	CameraDirection.Normalize();

	// �J�����ʒu
	FVector DesiredCameraLocation = CenterLocation + CameraDirection * CameraDistance;

	// �J��������
	DesiredCameraLocation.Z += 100.0f;


	// ���S������
	FVector LookDirection = CenterLocation - DesiredCameraLocation;

	FRotator DesiredRotation = LookDirection.Rotation();


	// �J�����ړ�
	const float InterpSpeed = TargetLockCameraSetting.InterpSpeed;

	FVector NewLocation =FMath::VInterpTo(CameraComp->GetComponentLocation(),DesiredCameraLocation,DeltaTime,InterpSpeed);


	FRotator NewRotation =FMath::RInterpTo(CameraComp->GetComponentRotation(),DesiredRotation,DeltaTime,InterpSpeed);


	CameraComp->SetWorldLocation(NewLocation);
	CameraComp->SetWorldRotation(NewRotation);
}

void UCameraSystemComponent::SetCameraMode(ECameraMode NewMode)
{
	if (CurrentCameraMode == NewMode)
	{
		return;
	}

	CurrentCameraMode = NewMode;

	UE_LOG(LogTemp,Log,TEXT("Camera Mode Changed : %d"),static_cast<int32>(CurrentCameraMode));
}

//�^�[�Q�b�g���Z�b�g
void UCameraSystemComponent::SetTargetComponent(UPlayerTargetComponent* TargetComponent)
{
	TargetComp = TargetComponent;
}

//�J������ʏ��Ԃɖ߂�����
void UCameraSystemComponent::UpdateReturnToNormalCamera(float DeltaTime)
{
	if (!SpringArmComp || !CameraComp)return;

	// SpringArm��]
	const FRotator CurrentSpringRotation =SpringArmComp->GetComponentRotation();

	const FRotator DesiredSpringRotation =NormalCameraReturnTargetRotation;

	const FRotator NewSpringRotation =FMath::RInterpTo(CurrentSpringRotation,DesiredSpringRotation,DeltaTime,NormalCameraReturnInterpSpeed);

	SpringArmComp->SetWorldRotation(NewSpringRotation);

	// SpringArm�ݒ�
	SpringArmComp->TargetArmLength =FMath::FInterpTo(SpringArmComp->TargetArmLength,NormalCameraSetting.ArmLength,DeltaTime,NormalCameraReturnInterpSpeed);

	SpringArmComp->SocketOffset =FMath::VInterpTo(SpringArmComp->SocketOffset,NormalCameraSetting.SocketOffset,DeltaTime,NormalCameraReturnInterpSpeed);

	// Camera��SpringArm�֒Ǐ]
	const FVector DesiredCameraLocation =SpringArmComp->GetSocketLocation(TEXT("SpringEndpoint"));

	const FRotator DesiredCameraRotation =SpringArmComp->GetSocketRotation(TEXT("SpringEndpoint"));

	const FVector NewCameraLocation =FMath::VInterpTo(CameraComp->GetComponentLocation(),DesiredCameraLocation,DeltaTime,NormalCameraReturnInterpSpeed);

	const FRotator NewCameraRotation =FMath::RInterpTo(CameraComp->GetComponentRotation(),DesiredCameraRotation,DeltaTime,NormalCameraReturnInterpSpeed);

	CameraComp->SetWorldLocation(NewCameraLocation);
	CameraComp->SetWorldRotation(NewCameraRotation);

	// ���A��������
	const float RotationDistance =FMath::Abs(FMath::FindDeltaAngleDegrees(SpringArmComp->GetComponentRotation().Yaw,NormalCameraReturnTargetRotation.Yaw));

	const float PitchDistance =FMath::Abs(SpringArmComp->GetComponentRotation().Pitch -NormalCameraReturnTargetRotation.Pitch);

	const float ArmLengthDistance =FMath::Abs(SpringArmComp->TargetArmLength -NormalCameraSetting.ArmLength);

	if (RotationDistance < 1.0f &&PitchDistance < 1.0f &&ArmLengthDistance < 1.0f)
	{
		// ���A�C��
		CameraComp->AttachToComponent(SpringArmComp,FAttachmentTransformRules::SnapToTargetNotIncludingScale);

		CameraComp->SetRelativeLocation(FVector::ZeroVector);

		CameraComp->SetRelativeRotation(FRotator::ZeroRotator);

		CameraComp->FieldOfView =NormalCameraSetting.FOV;

		bReturningToNormalCamera = false;

		UE_LOG(LogTemp,Warning,TEXT("===== CAMERA RETURN COMPLETE ====="));
	}
}

//�^�[�Q�b�g���擾
AActor* UCameraSystemComponent::GetCurrentTarget() const
{
	if (!TargetComp)
	{
		return nullptr;
	}

	return TargetComp->GetCurrentTargetActor();
}

FVector UCameraSystemComponent::GetEnemyTargetPoint() const
{
	if (!TargetComp)
	{
		return FVector::ZeroVector;
	}

	AActor* TargetActor = TargetComp->GetCurrentTargetActor();

	if (!TargetActor)
	{
		return FVector::ZeroVector;
	}

	FVector TargetLocation = TargetActor->GetActorLocation();

	TargetLocation.Z += EnemyTargetPointHeight;

	return TargetLocation;
}

//�^�[�Q�b�g���Ă��邩
bool UCameraSystemComponent::IsTargeting() const
{
	if (!TargetComp)
	{
		return false;
	}

	return TargetComp->IsTargeting();
}

FCameraSetting UCameraSystemComponent::GetCurrentCameraSetting() const
{
	switch (CurrentCameraMode)
	{
	case ECameraMode::Normal:
		return NormalCameraSetting;


	case ECameraMode::TargetLock:
		return TargetLockCameraSetting;


	case ECameraMode::BossBattle:
		return BossBattleCameraSetting;
	}

	return NormalCameraSetting;
}
