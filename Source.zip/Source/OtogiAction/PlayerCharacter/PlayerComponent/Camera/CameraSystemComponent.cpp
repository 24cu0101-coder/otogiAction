// Fill out your copyright notice in the Description page of Project Settings.


#include "CameraSystemComponent.h"
#include "MoveCameraComponent.h"
#include "../PlayerTargetComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

//�R���X�g���N�^
UCameraSystemComponent::UCameraSystemComponent()
{
	//Tick�͖�����
	PrimaryComponentTick.bCanEverTick = true;

	MoveCameraComp = nullptr;
	TargetComp = nullptr;

	SpringArmComp = nullptr;
	CameraComp = nullptr;

	CameraPivotComp = nullptr;

	// ������Ԃ͒ʏ�J����
	CurrentCameraMode = ECameraMode::Normal;

	//==================================================
	// �m�[�}���J�����ݒ�
	//==================================================

	NormalCameraSetting.ArmLength = 400.0f;
	NormalCameraSetting.FOV = 90.0f;
	NormalCameraSetting.SocketOffset = FVector::ZeroVector;
	NormalCameraSetting.InterpSpeed = 8.0f;


	//==================================================
	// �^�[�Q�b�g�J�����ݒ�
	//==================================================

	TargetLockCameraSetting.ArmLength = 400.0f;
	TargetLockCameraSetting.FOV = 90.0f;
	TargetLockCameraSetting.SocketOffset = FVector::ZeroVector;
	TargetLockCameraSetting.InterpSpeed = 8.0f;


	//==================================================
	// �{�X�퓬�J�����ݒ�
	//==================================================

	BossBattleCameraSetting.ArmLength = 500.0f;
	BossBattleCameraSetting.FOV = 85.0f;
	BossBattleCameraSetting.SocketOffset = FVector::ZeroVector;
	BossBattleCameraSetting.InterpSpeed = 5.0f;
}


// �������ꂽ�Ƃ����������
void UCameraSystemComponent::BeginPlay()
{
	Super::BeginPlay();

	ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());

	if (!OwnerCharacter)return;

	SpringArmComp = OwnerCharacter->FindComponentByClass<USpringArmComponent>();

	CameraComp = OwnerCharacter->FindComponentByClass<UCameraComponent>();
	
}

void UCameraSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime,TickType,ThisTickFunction);

	//�J�����ݒ�K��
	ApplyCameraSetting(DeltaTime);

	//�J�������[�h
	switch (CurrentCameraMode)
	{
	case ECameraMode::Normal:

		break;


	case ECameraMode::TargetLock:

		UpdateTargetLockCamera(DeltaTime);

		break;


	case ECameraMode::BossBattle:

		break;
	}
}


void UCameraSystemComponent::SetMoveCameraComponent(UMoveCameraComponent* CameraComponent)
{
	MoveCameraComp = CameraComponent;
}

void UCameraSystemComponent::ApplyCameraSetting(float DeltaTime)
{
	if (!SpringArmComp || !CameraComp)return;

	FCameraSetting Setting =GetCurrentCameraSetting();


	SpringArmComp->TargetArmLength =FMath::FInterpTo(SpringArmComp->TargetArmLength,Setting.ArmLength,DeltaTime,Setting.InterpSpeed);


	CameraComp->FieldOfView =FMath::FInterpTo(CameraComp->FieldOfView,Setting.FOV,DeltaTime,Setting.InterpSpeed);


	SpringArmComp->SocketOffset =FMath::VInterpTo(SpringArmComp->SocketOffset,Setting.SocketOffset,DeltaTime,Setting.InterpSpeed);
}

void UCameraSystemComponent::CameraMove(const FVector2D& InputValue)
{
	if (!MoveCameraComp) return;

	if (CurrentCameraMode == ECameraMode::TargetLock) return;

	MoveCameraComp->CameraMove(InputValue);
}

void UCameraSystemComponent::SetCameraPivotComponent(USceneComponent* CameraPivot)
{
	CameraPivotComp = CameraPivot;
}

void UCameraSystemComponent::ToggleTargetLock()
{
	if (!TargetComp) return;



	TargetComp->ToggleTargetLock();

	if (TargetComp->IsTargeting())
	{
		SetCameraMode(ECameraMode::TargetLock);
	}
	else
	{
		SetCameraMode(ECameraMode::Normal);
	}
}

void UCameraSystemComponent::UpdateTargetLockCamera(float DeltaTime)
{
	if (!TargetComp)return;

	if (!CameraPivotComp)return;

	AActor* TargetActor =TargetComp->GetCurrentTargetActor();

	if (!TargetActor)return;

	// CameraPivot�̈ʒu
	FVector CameraLocation =CameraPivotComp->GetComponentLocation();

	// �G�̈ʒu
	FVector TargetLocation =TargetActor->GetActorLocation();

	// CameraPivot����G�ւ̕���
	FVector Direction =TargetLocation - CameraLocation;

	if (Direction.IsNearlyZero())return;

	// �G�����̉�]
	FRotator TargetRotation =Direction.Rotation();

	// ���݂�Pivot��]
	FRotator CurrentRotation =CameraPivotComp->GetComponentRotation();

	// ���炩�ɓG�֌�����
	FRotator NewRotation =FMath::RInterpTo(CurrentRotation,TargetRotation,DeltaTime,TargetLockCameraSetting.InterpSpeed);

	CameraPivotComp->SetWorldRotation(NewRotation);
}

void UCameraSystemComponent::SetCameraMode(ECameraMode NewMode)
{
	if (CurrentCameraMode == NewMode)
	{
		return;
	}

	CurrentCameraMode = NewMode;

	UE_LOG(LogTemp,Log,TEXT("Camera Mode Changed : %d"),static_cast<int32>(CurrentCameraMode));
}

//�^�[�Q�b�g���Z�b�g
void UCameraSystemComponent::SetTargetComponent(UPlayerTargetComponent* TargetComponent)
{
	TargetComp = TargetComponent;
}

//�^�[�Q�b�g���擾
AActor* UCameraSystemComponent::GetCurrentTarget() const
{
	if (!TargetComp)
	{
		return nullptr;
	}

	return TargetComp->GetCurrentTargetActor();
}

//�^�[�Q�b�g���Ă��邩
bool UCameraSystemComponent::IsTargeting() const
{
	if (!TargetComp)
	{
		return false;
	}

	return TargetComp->IsTargeting();
}

FCameraSetting UCameraSystemComponent::GetCurrentCameraSetting() const
{
	switch (CurrentCameraMode)
	{
	case ECameraMode::Normal:
		return NormalCameraSetting;


	case ECameraMode::TargetLock:
		return TargetLockCameraSetting;


	case ECameraMode::BossBattle:
		return BossBattleCameraSetting;
	}

	return NormalCameraSetting;
}
