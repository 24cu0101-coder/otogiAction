//�S���F�ѓ�

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CameraDirectorComponent.generated.h"

//�O���錾
class UActionCameraSettingDataAsset;
class UCameraModifierDataAsset;
class ULevelSequence;
class ULevelSequencePlayer;
class APlayerCharacter;
class UMoveCameraComponent;
class USpringArmComponent;
class UCameraComponent;
class UPlayerTargetComponent;

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class OTOGIACTION_API UCameraDirectorComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	//�R���X�g���N�^
	UCameraDirectorComponent();

protected:
	// �Q�[���J�n���Ɛ������ɌĂ΂��
	virtual void BeginPlay() override;

public:
	// ���t���[���Ă΂��
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;


	//==================================================
	// Action Camera
	//==================================================

	UFUNCTION(BlueprintCallable, Category = "Camera|Action")
	void SetActionCameraEnabled(bool bEnabled);


	UFUNCTION(BlueprintCallable, Category = "Camera|Action")
	void SetBossCameraEnabled(bool bEnabled);


	UFUNCTION(BlueprintCallable, Category = "Camera|Action")
	void SetActionCameraSetting(UActionCameraSettingDataAsset* NewSetting);


	//==================================================
	// Modifier
	//==================================================

	UFUNCTION(BlueprintCallable, Category = "Camera|Modifier")
	void SetModifier(UCameraModifierDataAsset* Modifier,float Weight);


	UFUNCTION(BlueprintCallable, Category = "Camera|Modifier")
	void ClearModifier(UCameraModifierDataAsset* Modifier);


	UFUNCTION(BlueprintCallable, Category = "Camera|Modifier")
	void ClearAllModifiers();


protected:

	//==================================================
	// Action Camera
	//==================================================

	void UpdateActionCamera(float DeltaTime);

	//�����_�t�^
	FVector CalculateCombatFocusPoint() const;

	//�J���������̌v�Z
	float CalculateCombatCameraDistance() const;

	//�t�H�[�J�X�_�փJ������������
	void UpdateCombatRotation(const FVector& FocusPoint,float DeltaTime);

	//==================================================
	// Modifier
	//==================================================

	void ApplyModifier(float DeltaTime);

private:
	//==================================================
	// �|�C���^�[
	//==================================================

	UPROPERTY()
	TObjectPtr<APlayerCharacter> m_PlayerCharacter;

	UPROPERTY()
	TObjectPtr<UPlayerTargetComponent> m_PlayerTargetComponent;

	UPROPERTY()
	TObjectPtr<USpringArmComponent> m_SpringArmComponent;

	UPROPERTY()
	TObjectPtr<UCameraComponent> m_CameraComponent;


	//==================================================
	// �J�����f�[�^�A�Z�b�g
	//==================================================

	UPROPERTY(EditAnywhere, Category = "Camera|Action")
	TObjectPtr<UActionCameraSettingDataAsset> m_GameplayCameraSetting;

	UPROPERTY(EditAnywhere, Category = "Camera|Action")
	TObjectPtr<UActionCameraSettingDataAsset> m_LockOnCameraSetting;

	UPROPERTY(EditAnywhere, Category = "Camera|Action")
	TObjectPtr<UActionCameraSettingDataAsset> m_BossCameraSetting;


	UPROPERTY()
	TObjectPtr<UActionCameraSettingDataAsset> m_CurrentCameraSetting;


	//==================================================
	// �J�����X�e�[�g
	//==================================================

	UPROPERTY(EditAnywhere, Category = "Camera|Action")
	bool bActionCameraEnabled = true;

	bool bBossCameraEnabled = false;


	//==================================================
	// Modifier
	//==================================================

	struct FActiveModifier
	{
		TObjectPtr<UCameraModifierDataAsset> Data = nullptr;

		float Weight = 0.0f;
	};

	TArray<FActiveModifier> ActiveModifiers;
};
