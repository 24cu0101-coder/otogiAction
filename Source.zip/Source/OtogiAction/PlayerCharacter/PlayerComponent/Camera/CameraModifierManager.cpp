//�S���F�ѓ�
//Modifier���Ǘ�����N���X

#include "CameraModifierManager.h"

//�R���X�g���N�^
UCameraModifierManager::UCameraModifierManager()
{
	PrimaryComponentTick.bCanEverTick = false;
}


//�������ꂽ�Ƃ��ɏ��������
void UCameraModifierManager::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}

//Modifier�̍X�V
void UCameraModifierManager::UpdateModifiers(float DeltaTime, FCameraModifierData& OutData)
{
    OutData = FCameraModifierData();

    for (int32 Index = ActiveModifiers.Num() - 1;
        Index >= 0;
        --Index)
    {
        UCameraModifier* Modifier = ActiveModifiers[Index];

        if (!Modifier)
        {
            ActiveModifiers.RemoveAt(Index);
            continue;
        }

        Modifier->UpdateModifier(DeltaTime,OutData);

        if (Modifier->IsFinished())
        {
            ActiveModifiers.RemoveAt(Index);
        }
    }
}

//Modifier�ǉ�
void UCameraModifierManager::AddModifier(UCameraModifier* Modifier)
{
    if (!Modifier)
    {
        return;
    }

    ActiveModifiers.AddUnique(Modifier);
}

//Modifier�̎��O��
void UCameraModifierManager::RemoveModifier(UCameraModifier* Modifier)
{
    ActiveModifiers.Remove(Modifier);
}

//Modifier�̍폜
void UCameraModifierManager::ClearModifiers()
{
    ActiveModifiers.Empty();
}