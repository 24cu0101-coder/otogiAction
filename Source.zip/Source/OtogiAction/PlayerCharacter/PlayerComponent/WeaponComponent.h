// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "WeaponComponent.generated.h"

//����̃X�^�C�����`
UENUM(BlueprintType)
enum class  EPlayerWeaponStyle : uint8
{
	Nomal	UMETA(DisplayName = "Normal"),
	Kintaro	UMETA(DisplayName = "Kintaro"),
};

//�O���錾
class UNiagaraComponent;

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class OTOGIACTION_API UWeaponComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UWeaponComponent();

	//�X�^�C���̐؂�ւ�
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void SetWeaponStyle(EPlayerWeaponStyle PlayerStyle);
	
	//���݂̃X�^�C�����擾
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	EPlayerWeaponStyle GetCurrentStyle() const { return CurrentStyle; }

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;


protected:
	//���A�N�^�[
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
	TSubclassOf<AActor>WeaponActorClass;

	//�����Y�I�[��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon | Effect")
	UNiagaraComponent* KintaroEffectComp;

	//�^�O���ǉ��E���������Ƃ��ɌĂ΂��֐�
	void OnKintaroTagChanged(const FGameplayTag CallbackTag, int32 NewCount);
	
private:
	// ���݂̃X�^�C��
	UPROPERTY(VisibleAnywhere, Category = "Weapon | State")
	EPlayerWeaponStyle CurrentStyle = EPlayerWeaponStyle::Nomal;

	void SetActorHidden(AActor* TargetActor, bool bNewHidden);
};
