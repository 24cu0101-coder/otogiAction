// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "GameplayTagContainer.h"
#include "SheathingNotify.generated.h"

/**
 * 
 */
UCLASS()
class OTOGIACTION_API USheathingNotify : public UAnimNotify
{
	GENERATED_BODY()

public:
	// �ʒm�̏���
	virtual void Notify(USkeletalMeshComponent* MeshComp,
		UAnimSequenceBase* Animation, 
		const FAnimNotifyEventReference& EventReference)
		override;

	// �A�j���[�V�����G�f�B�^�̏ڍ׃p�l���Őݒ肷��^�O
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SheathingNotifyEvent")
	FGameplayTag SheathingTag;

	
};
