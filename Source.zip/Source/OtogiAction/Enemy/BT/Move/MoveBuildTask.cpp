// Fill out your copyright notice in the Description page of Project Settings.


#include "MoveBuildTask.h"
#include "Kismet/GameplayStatics.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "GameFramework/Character.h"
#include "Animation/AnimInstance.h"
#include "../../Component/MoveBuildComponent.h"

UMoveBuildTask::UMoveBuildTask()
{
	NodeName = "MoveBuild Task";
	bNotifyTick = true;
}

EBTNodeResult::Type UMoveBuildTask::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
    AAIController* EnemyController = OwnerComp.GetAIOwner();
    ACharacter* EnemyCharacter = EnemyController ? Cast<ACharacter>(EnemyController->GetPawn()) : nullptr;
    if (!EnemyCharacter) return EBTNodeResult::Failed;

    APawn* TargetPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
    if (EnemyController && TargetPawn)
    {
        EnemyController->SetFocus(TargetPawn);
    }
    UMoveBuildComponent* BuildComp = EnemyCharacter->FindComponentByClass<UMoveBuildComponent>();
    if (!BuildComp) return EBTNodeResult::Failed;

    //�ړ��J�n���ɃX�e�[�g��ύX����
    BuildComp->SetEnemyState();

    //�ǐՂ��J�n
    bool bStarted = BuildComp->StartTracking();

    //�ǐՂ��J�n����Ă�����InProgress��Ԃ�
    if (bStarted)
    {
        return EBTNodeResult::InProgress;
    }

    return EBTNodeResult::Failed;
}

void UMoveBuildTask::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
    Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

    AAIController* EnemyController = OwnerComp.GetAIOwner();
    ACharacter* EnemyCharacter = EnemyController ? Cast<ACharacter>(EnemyController->GetPawn()) : nullptr;
    if (!EnemyCharacter)
    {
        FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
        return;
    }

    UMoveBuildComponent* BuildComp = EnemyCharacter->FindComponentByClass<UMoveBuildComponent>();
    if (!BuildComp)
    {
        FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
        return;
    }

    //�ǐՏ�Ԃ̍X�V�������Ă�
    BuildComp->UpdateTrackingStatus();

    // �ǐՊ�������i�܂��͖ڕW���B���Ȃǁj
    if (!BuildComp->IsTracking())
    {
        FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
    }

}
