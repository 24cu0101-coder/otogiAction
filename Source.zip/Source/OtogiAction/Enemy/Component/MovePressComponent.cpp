// Fill out your copyright notice in the Description page of Project Settings.


#include "MovePressComponent.h"
#include "../EnemyStateSubsystem.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "AIController.h"
#include "Navigation/PathFollowingComponent.h"

UMovePressComponent::UMovePressComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	// �_�b�V���͉������i600?1500�j�̂Ƃ��ɕ]���������Ȃ�悤�ݒ�
	MinRange = 600.f;
	MaxRange = 1500.f;
	FadeOutRange = 2500.f;
	BasePriority = 0.8f; // �ʏ�ړ����D��x�������ݒ�
}

void UMovePressComponent::SetEnemyState()
{
	if (UWorld* World = GetWorld())
	{
		// 2. GameInstance ���擾���� Subsystem ���Ăяo��
		if (UGameInstance* GI = World->GetGameInstance())
		{
			if (UEnemyStateSubsystem* StateSubsystem = GI->GetSubsystem<UEnemyStateSubsystem>())
			{
				// ��Ԃ̕ύX
				StateSubsystem->CurrentState = EEnemyState::MovePress;
			}
		}
	}

}

bool UMovePressComponent::StartDashTracking()
{
	SetEnemyState();

	APawn* OwnerPawn = Cast<APawn>(GetOwner());
	if (!OwnerPawn) return false;

	AAIController* AIController = Cast<AAIController>(OwnerPawn->GetController());
	APawn* TargetPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);

	if (!AIController || !TargetPawn) return false;

	// �_�b�V�����x�̐ݒ�
	if (ACharacter* OwnerCharacter = Cast<ACharacter>(OwnerPawn))
	{
		if (UCharacterMovementComponent* MoveComp = OwnerCharacter->GetCharacterMovement())
		{
			MoveComp->MaxWalkSpeed = DashSpeed;
		}
	}

	// �ړ��J�n
	EPathFollowingRequestResult::Type MoveResult = AIController->MoveToActor(TargetPawn, 200.0f);
	bIsDashTracking = (MoveResult != EPathFollowingRequestResult::Type::Failed);

	return bIsDashTracking;
}

void UMovePressComponent::FinishDashTracking()
{
	bIsDashTracking = false;

	//�I��������Idle�ɖ߂�
	if (UWorld* World = GetWorld()) {
		if (UGameInstance* GI = World->GetGameInstance()) {
			if (UEnemyStateSubsystem* StateSubsystem = GI->GetSubsystem<UEnemyStateSubsystem>()) {
				StateSubsystem->CurrentState = EEnemyState::Idle;
			}
		}
	}
}