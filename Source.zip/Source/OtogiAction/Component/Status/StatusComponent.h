#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "StatusComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(
	FOnDamaged,
	float,
	CurrentHP);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(
	FOnDead);

class UNiagaraSystem;

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class OTOGIACTION_API UStatusComponent
 : public UActorComponent
{
	GENERATED_BODY()

public:

	UStatusComponent();

protected:

	virtual void BeginPlay() override;



public:

	// �ő�HP
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Status")
	float MaxHP = 100.f;

	// ����HP
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Status")
	float CurrentHP = 1000.f;

	// �U����
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Status")
	float Attack = 20.f;

	// �_���[�W�ʒm
	UPROPERTY(BlueprintAssignable)
	FOnDamaged OnDamaged;

	// ���S�ʒm
	UPROPERTY(BlueprintAssignable)
	FOnDead OnDead;

	// �_���[�W
	UFUNCTION(BlueprintCallable)
	void TakeDamage(float DamageAmount);

	// ��
	UFUNCTION(BlueprintCallable)
	void Heal(float HealAmount);

	// ���S����
	UFUNCTION(BlueprintCallable)
	bool IsDead() const;

	float GetCurrentHP() const
	{
		return CurrentHP;
	}
	float GetMaxHP() const
	{
		return MaxHP;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Status")
	UNiagaraSystem* DarkParticleAsset;

private:
	//�G�̃p�[�e�B�N�������֐�
	void SpawnDarkParticleOnDamage(FVector SpawnLocation);

	//���G���ǂ���
	bool PlayerInvincible();
};