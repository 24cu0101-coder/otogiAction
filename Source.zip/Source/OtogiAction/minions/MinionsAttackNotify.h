#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "MinionsAttackNotify.generated.h"

class USoundBase;

UCLASS()
class OTOGIACTION_API UMinionsAttackNotify : public UAnimNotify
{
	GENERATED_BODY()

public:

	virtual void Notify(
		USkeletalMeshComponent* MeshComp,
		UAnimSequenceBase* Animation
	) override;


public:

	//攻撃範囲
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack")
	float Radius = 100.f;


	//ダメージ
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack")
	float Damage = 20.f;

	//スタン値
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack")
	float StunPoint = 10.f;

	//前方向へのずらし
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack")
	float ForwardOffset = 50.f;


	//横方向へのずらし
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack")
	float SideOffset = 0.f;

	//ヒットサウンド再生
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attack|Sound")
	USoundBase* HitSound = nullptr;



};