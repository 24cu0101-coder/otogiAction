#pragma once

#include "CoreMinimal.h"
#include "Abilities/GameplayAbility.h"
#include "Animation/AnimMontage.h"
#include "NiagaraSystem.h"
#include "GA_minionsAttack_Strong.generated.h"


UCLASS()
class OTOGIACTION_API UGA_minionsAttack_Strong : public UGameplayAbility
{
	GENERATED_BODY()

public:

	UGA_minionsAttack_Strong();


	virtual void ActivateAbility(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo,
		const FGameplayEventData* TriggerEventData
	) override;


protected:

	// 予備動作Montage
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation")
	TObjectPtr<UAnimMontage> PreAttackMontage;

	// 攻撃Montage
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation")
	TObjectPtr<UAnimMontage> AttackMontage;


	// ダメージ
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Attack")
	float Damage = 30.f;

	//エフェクト
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Effect")
	UNiagaraSystem* AttackEffect = nullptr;

	// 予備動作終了
	UFUNCTION()
	void OnPreAttackCompleted();


	// 予備動作中断
	UFUNCTION()
	void OnPreAttackInterrupted();


	// Montage終了
	UFUNCTION()
	void OnMontageCompleted();

	UFUNCTION()
	void OnMontageInterrupted();


private:

	FGameplayAbilitySpecHandle CurrentSpecHandle;

	const FGameplayAbilityActorInfo* CurrentActorInfo;

	FGameplayAbilityActivationInfo CurrentActivationInfo;

};