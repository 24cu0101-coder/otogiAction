#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AbilitySystemInterface.h"
#include "AbilitySystemComponent.h"
#include "Abilities/GameplayAbility.h"
#include "Components/WidgetComponent.h"
#include "OtogiAction/Orb/OrbSpawnComponent.h"
#include "OtogiAction/Component/Audio/CharacterAudioComponent.h"
#include "NiagaraSystem.h"
#include "MinionsCharacter.generated.h"

class UStatusComponent;
class UminionsAttackComponent;
class UWidgetComponent;
class USphereCollisionComponent;
class UMinionsHitReactionComponent;


UCLASS()
class OTOGIACTION_API AMinionsCharacter : public ACharacter, public IAbilitySystemInterface
{
	GENERATED_BODY()

public:
	AMinionsCharacter();

protected:
	virtual void BeginPlay() override;

public:

	virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;

	virtual void Tick(float DeltaTime) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	// GAS
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "GAS")
	UAbilitySystemComponent* AbilitySystemComponent;

	void GiveDefaultAbilities();

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "GAS")
	TArray<TSubclassOf<UGameplayAbility>> DefaultAbilities;

	// Component
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UStatusComponent* StatusComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UminionsAttackComponent* AttackComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UOrbSpawnComponent* OrbSpawnComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UWidgetComponent* HPWidgetComponent;

	//Audio
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Component")
	UCharacterAudioComponent* CharacterAudioComponent;

	UPROPERTY()
	USphereCollisionComponent* SphereCollisionComponent;

	//HitReaction
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UMinionsHitReactionComponent* HitReactionComponent;


	UPROPERTY(BlueprintReadOnly)
	bool bIsAttacking = false;

	UPROPERTY(EditAnywhere, category = "Effect")
	UNiagaraSystem* HitEffect;

	//SpecialAbility
	UPROPERTY(EditAnywhere, BlueprintReadWrite, category = "Enemy")
	bool bKintaroOnlyEnemy = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Enemy")
	bool bCanTakeDamage = false;

	UPROPERTY(EditAnywhere,BlueprintReadWrite,category="HP Widget",meta=(AllowPrivateAccess="true"))
	float HPWidgetVisibleDistance = 1500.0f;

	void SetCanTakeDamage(bool bEnable)
	{
		bCanTakeDamage = bEnable;

		UE_LOG(LogTemp, Warning,
			TEXT("%s SetCanTakeDamage : %d"),
			*GetName(),
			bCanTakeDamage);
	}

	// Orb状態
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Orb")
	bool bCanSpawnOrb = false;

	//攻撃速度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	float AttackPlayRate = 1.0f;
	
public:

	void CancelAttack();
	void SetIsAttacking(bool Value)
	{
		bIsAttacking = Value;
	}


	bool IsAttacking() const
	{
		return bIsAttacking;
	}

	// Event
	UFUNCTION()
	void OnDamage(AActor* DamagedActor,float Damage,const UDamageType* DamageType,AController* InstigatedBy,AActor* DamageCauser);

	UFUNCTION()
	void Dead();

	UFUNCTION()
	void UpdateHPWidget(float CurrentHP);

	void SetCanSpawnOrb(bool bEnable);

	void UpdateHPWidgetVisibility();

private:
	bool bIsHit = false;

public:
	bool GetIsHitFlg() const { return bIsHit; }
	void SetIsHitFlg(bool bHit) { bIsHit = bHit; }

	bool IsDead() const { return bIsDead; }
	

private:

	bool bIsDead = false;
};