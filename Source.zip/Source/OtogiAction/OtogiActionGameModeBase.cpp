// Fill out your copyright notice in the Description page of Project Settings.

#include "OtogiActionGameModeBase.h"

#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"

#include "OtogiAction/phase/phaseManager.h"


// �R���X�g���N�^
AOtogiActionGameModeBase::AOtogiActionGameModeBase()
{
}


// �Q�[���J�n��
void AOtogiActionGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	// �Q�[���J�n����̃v���C���[�ʒu��ۑ�
	APlayerController* PC = GetWorld()->GetFirstPlayerController();

	if (PC && PC->GetPawn())
	{
		CurrentCheckpointTransform =
			PC->GetPawn()->GetActorTransform();
	}
}


// �`�F�b�N�|�C���g�X�V
void AOtogiActionGameModeBase::SetCheckPoint(FTransform NewTransform)
{
	CurrentCheckpointTransform = NewTransform;

	UE_LOG(
		LogTemp,
		Warning,
		TEXT("Checkpoint Update")
	);
}


// �v���C���[����
void AOtogiActionGameModeBase::RespawmPlayer(AController* TargetController)
{
	if (!TargetController)
	{
		return;
	}

	// PhaseManager�擾

	AphaseManager* PhaseManager =
		Cast<AphaseManager>(
			UGameplayStatics::GetActorOfClass(
				GetWorld(),
				AphaseManager::StaticClass()
			)
		);

	// ���X�|�[���J�n

	if (PhaseManager)
	{
		PhaseManager->SetRespawning(true);
	}

	// ���݂̃v���C���[���폜

	APawn* OldPawn = TargetController->GetPawn();

	if (OldPawn)
	{
		OldPawn->Destroy();
	}

	// ���݂̃t�F�[�Y�̓G�𕜊�

	if (PhaseManager)
	{
		PhaseManager->RespawnCurrentPhaseMinions();
	}

	// ���X�|�[���ʒu

	FTransform RespawnTransform =
		CurrentCheckpointTransform;

	if (PhaseManager)
	{
		RespawnTransform =
			PhaseManager->GetRespawnTransform();

		UE_LOG(
			LogTemp,
			Warning,
			TEXT("Respawn Phase: %d"),
			(int32)PhaseManager->GetCurrentPhase()
		);
	}

	// �v���C���[����

	FActorSpawnParameters SpawnParams;

	SpawnParams.SpawnCollisionHandlingOverride =
		ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	if (RespawnPlayerClass)
	{
		APawn* NewPawn =
			GetWorld()->SpawnActor<APawn>(
				RespawnPlayerClass,
				RespawnTransform,
				SpawnParams
			);

		if (NewPawn)
		{
			TargetController->Possess(NewPawn);

			UE_LOG(
				LogTemp,
				Warning,
				TEXT("===== NEW PLAYER RESPAWNED =====")
			);
		}
	}
	else
	{
		UE_LOG(
			LogTemp,
			Error,
			TEXT("RespawnPlayerClass is NOT set!")
		);
	}
	// ���X�|�[���I��

	if (PhaseManager)
	{
		PhaseManager->SetRespawning(false);
	}
}


// �V�[���J��
void AOtogiActionGameModeBase::ChangeLevel(FName LevelName)
{
	if (!LevelName.IsNone())
	{
		UGameplayStatics::OpenLevel(
			this,
			LevelName
		);
	}
}